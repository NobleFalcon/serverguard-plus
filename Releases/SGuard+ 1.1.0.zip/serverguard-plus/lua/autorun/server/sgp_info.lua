include( "sgp_init.lua" )

SGPlus.Version = "1.1.0"

-- Display current version.
SGPlus.PrintConsole( SGPlus.WHITE , string.format( "Loaded SGuard+ version %s", SGPlus.Version ) )