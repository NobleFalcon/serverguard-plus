include( "sgp_init.lua" )

SGPlus.Version = "1.0.1"

-- Display current version.
SGPlus.PrintConsole( SGPlus.BLUE, string.format( "You are running SGuard+ version %s", SGPlus.Version ) )