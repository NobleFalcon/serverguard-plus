include( "sgp_init.lua" );

SGPlus.Version = "1.0.0";

-- Display current version.
serverguard.PrintConsole( string.format( "You are running SGuard+ version %s \n", SGPlus.Version ) );