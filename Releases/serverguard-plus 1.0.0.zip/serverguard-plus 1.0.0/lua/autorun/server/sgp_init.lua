-- Included in every file.
SGPlus = SGPlus or {};