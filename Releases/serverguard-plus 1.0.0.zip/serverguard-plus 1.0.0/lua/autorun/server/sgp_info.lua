include( "sgp_init.lua" );

SGPlus.Version = "1.0.0";

-- Display current version.
serverguard.PrintConsole( "You are running SGuard+ version " .. SGPlus.Version .. "\n" );